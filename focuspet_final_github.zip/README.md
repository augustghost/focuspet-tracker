
# FocusPet Tracker (GitHub Pages Edition)

🐾 A virtual pet productivity app to help ADHD users stay focused and motivated.

## 🚀 How to Deploy

1. Upload this folder to a new GitHub repository.
2. Go to **Settings > Pages** and set:
   - Source: `main`
   - Folder: `/ (root)`
3. Save. Your app will be live at:
   `https://yourusername.github.io/reponame/`

## Features

- Mood-changing pet
- Unlockable outfits
- Daily rewards
- Installable as a mobile PWA

Enjoy!
